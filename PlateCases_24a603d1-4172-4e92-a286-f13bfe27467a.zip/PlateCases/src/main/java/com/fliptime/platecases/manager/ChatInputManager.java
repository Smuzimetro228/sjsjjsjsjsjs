package com.fliptime.platecases.manager;

import com.fliptime.platecases.PlateCasesPlugin;
import com.fliptime.platecases.util.Text;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/** Введення значень через чат для GUI-редактора. */
public class ChatInputManager implements Listener {

    private final PlateCasesPlugin plugin;
    private final Map<UUID, Consumer<String>> pending = new ConcurrentHashMap<>();

    public ChatInputManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    public void ask(Player p, String what, Consumer<String> handler) {
        UUID id = p.getUniqueId();
        pending.put(id, handler);
        p.closeInventory();
        plugin.messages().send(p, "input-prompt", "{what}", what);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (pending.get(id) == handler) {
                pending.remove(id);
                Player online = Bukkit.getPlayer(id);
                if (online != null) plugin.messages().send(online, "input-timeout");
            }
        }, 20L * 60);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        Consumer<String> handler = pending.remove(id);
        if (handler == null) return;
        e.setCancelled(true);
        final String text = Text.plain(e.message()).trim();
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player p = Bukkit.getPlayer(id);
            if (p == null) return;
            if (text.equalsIgnoreCase("cancel") || text.equalsIgnoreCase("скасувати")) {
                plugin.messages().send(p, "input-cancelled");
                return;
            }
            handler.accept(text);
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        pending.remove(e.getPlayer().getUniqueId());
    }
}
