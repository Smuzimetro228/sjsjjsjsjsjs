package com.fliptime.platecases.manager;

import com.fliptime.platecases.PlateCasesPlugin;
import com.fliptime.platecases.model.PlateDef;
import com.fliptime.platecases.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Пластинки: створення, перевірка підпису через PersistentDataContainer, збереження. */
public class PlateManager {

    private final PlateCasesPlugin plugin;
    private final NamespacedKey keyId;
    private final NamespacedKey keySig;
    private final Map<String, PlateDef> plates = new LinkedHashMap<>();
    private String secret = "";

    public PlateManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
        this.keyId = new NamespacedKey(plugin, "plate_id");
        this.keySig = new NamespacedKey(plugin, "plate_sig");
    }

    public void load() {
        plates.clear();
        secret = plugin.configs().config().getString("security.secret", "");
        if (secret == null || secret.isEmpty()) {
            secret = UUID.randomUUID() + "-" + UUID.randomUUID();
            plugin.configs().config().set("security.secret", secret);
            plugin.configs().saveConfig();
        }
        YamlConfiguration y = plugin.configs().loadYaml("items.yml");
        ConfigurationSection sec = y.getConfigurationSection("plates");
        if (sec == null) return;
        for (String rawId : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(rawId);
            if (s == null) continue;
            PlateDef d = new PlateDef(rawId.toLowerCase());
            d.level = Math.max(1, s.getInt("level", 1));
            d.name = s.getString("name", "&7Платівка");
            Material m = Material.matchMaterial(s.getString("material", "MUSIC_DISC_13"));
            if (m == null || !m.isItem() || m.isAir()) {
                plugin.getLogger().warning("Пластинка " + d.id + ": невірний матеріал, використано MUSIC_DISC_13");
                m = Material.MUSIC_DISC_13;
            }
            d.material = m;
            d.customModelData = Math.max(0, s.getInt("custom-model-data", 0));
            d.itemModel = s.getString("item-model", "");
            d.glow = s.getBoolean("glow", false);
            d.lore = new ArrayList<>(s.getStringList("lore"));
            d.chestName = s.getString("chest-name", "&8Скарбниця");
            d.openSound = s.getString("open-sound", "entity.player.levelup");
            d.soundVolume = (float) s.getDouble("sound-volume", 1.0);
            d.soundPitch = (float) s.getDouble("sound-pitch", 1.0);
            d.particles = s.getBoolean("particles", true);
            d.particle = s.getString("particle", "happy_villager");
            d.particleCount = Math.max(1, s.getInt("particle-count", 40));
            plates.put(d.id, d);
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.options().setHeader(List.of(
                "PlateCases — пластинки. Редагуються через /pcases menu або вручну (+ /pcases reload)."));
        for (PlateDef d : plates.values()) {
            String p = "plates." + d.id + ".";
            y.set(p + "level", d.level);
            y.set(p + "name", d.name);
            y.set(p + "material", d.material.name());
            y.set(p + "custom-model-data", d.customModelData);
            y.set(p + "item-model", d.itemModel);
            y.set(p + "glow", d.glow);
            y.set(p + "lore", d.lore);
            y.set(p + "chest-name", d.chestName);
            y.set(p + "open-sound", d.openSound);
            y.set(p + "sound-volume", d.soundVolume);
            y.set(p + "sound-pitch", d.soundPitch);
            y.set(p + "particles", d.particles);
            y.set(p + "particle", d.particle);
            y.set(p + "particle-count", d.particleCount);
        }
        plugin.configs().saveYamlAsync("items.yml", y);
    }

    public Collection<PlateDef> all() {
        return plates.values();
    }

    public PlateDef get(String id) {
        return id == null ? null : plates.get(id.toLowerCase());
    }

    public PlateDef byLevel(int level) {
        for (PlateDef d : plates.values()) if (d.level == level) return d;
        return null;
    }

    public PlateDef createNew(String id) {
        int max = 0;
        for (PlateDef d : plates.values()) max = Math.max(max, d.level);
        PlateDef d = new PlateDef(id);
        d.level = max + 1;
        d.name = "&7Платівка " + d.level + " рівня";
        d.chestName = "&7Скарбниця " + d.level + " рівня";
        d.lore = new ArrayList<>(List.of("&7Одноразовий ключ до сундука", "&7" + d.level + " рівня"));
        plates.put(id, d);
        plugin.loot().table(d.level);
        save();
        return d;
    }

    /** Створює предмет. tagged=false — лише для відображення у GUI (без PDC). */
    public ItemStack create(PlateDef d, int amount, boolean tagged) {
        ItemStack it = new ItemStack(d.material, Math.max(1, amount));
        ItemMeta m = it.getItemMeta();
        m.displayName(Text.item(d.name));
        if (!d.lore.isEmpty()) m.lore(Text.items(d.lore));
        if (d.customModelData > 0) {
            CustomModelDataComponent c = m.getCustomModelDataComponent();
            c.setFloats(List.of((float) d.customModelData));
            m.setCustomModelDataComponent(c);
        }
        if (d.itemModel != null && !d.itemModel.isBlank()) {
            NamespacedKey k = NamespacedKey.fromString(d.itemModel.toLowerCase());
            if (k != null) m.setItemModel(k);
        }
        if (d.glow) m.setEnchantmentGlintOverride(true);
        if (tagged) {
            PersistentDataContainer pdc = m.getPersistentDataContainer();
            pdc.set(keyId, PersistentDataType.STRING, d.id);
            pdc.set(keySig, PersistentDataType.STRING, sign(d.id));
        }
        it.setItemMeta(m);
        return it;
    }

    public void giveTo(Player p, PlateDef d, int amount) {
        int left = Math.max(1, amount);
        int max = Math.max(1, d.material.getMaxStackSize());
        while (left > 0) {
            int n = Math.min(left, max);
            Map<Integer, ItemStack> over = p.getInventory().addItem(create(d, n, true));
            for (ItemStack o : over.values()) p.getWorld().dropItemNaturally(p.getLocation(), o);
            left -= n;
        }
    }

    /** true, якщо предмет має мітки PlateCases (навіть підроблені). */
    public boolean isTagged(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(keyId, PersistentDataType.STRING);
    }

    /** Повертає визначення пластинки лише для справжньої (валідний id + підпис). */
    public PlateDef identify(ItemStack item) {
        if (!isTagged(item)) return null;
        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        String id = pdc.get(keyId, PersistentDataType.STRING);
        String sig = pdc.get(keySig, PersistentDataType.STRING);
        if (id == null || sig == null) return null;
        PlateDef d = plates.get(id);
        if (d == null) return null;
        boolean ok = MessageDigest.isEqual(sign(id).getBytes(StandardCharsets.UTF_8), sig.getBytes(StandardCharsets.UTF_8));
        return ok ? d : null;
    }

    private String sign(String id) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest((secret + ":" + id).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 12; i++) sb.append(String.format("%02x", h[i]));
            return sb.toString();
        } catch (Exception ex) {
            throw new IllegalStateException(ex);
        }
    }
}
