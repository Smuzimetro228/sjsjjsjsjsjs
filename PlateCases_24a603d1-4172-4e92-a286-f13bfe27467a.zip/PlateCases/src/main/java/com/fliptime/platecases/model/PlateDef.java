package com.fliptime.platecases.model;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.List;

/** Опис пластинки (з items.yml). */
public class PlateDef {
    public final String id;
    public int level = 1;
    public String name = "&7Платівка";
    public Material material = Material.MUSIC_DISC_13;
    public int customModelData = 0;
    public String itemModel = "";
    public boolean glow = false;
    public List<String> lore = new ArrayList<>();
    public String chestName = "&8Скарбниця";
    public String openSound = "entity.player.levelup";
    public float soundVolume = 1.0f;
    public float soundPitch = 1.0f;
    public boolean particles = true;
    public String particle = "happy_villager";
    public int particleCount = 40;

    public PlateDef(String id) {
        this.id = id;
    }
}
