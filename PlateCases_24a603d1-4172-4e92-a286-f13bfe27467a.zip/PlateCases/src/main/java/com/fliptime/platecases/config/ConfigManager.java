package com.fliptime.platecases.config;

import com.fliptime.platecases.PlateCasesPlugin;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/** Робота з YAML-файлами. Запис — асинхронний, послідовний (в одному потоці). */
public class ConfigManager {

    private static final String[] DEFAULT_FILES = {
            "config.yml", "messages.yml", "items.yml", "chests.yml",
            "loot/level1.yml", "loot/level2.yml", "loot/level3.yml"
    };

    private final PlateCasesPlugin plugin;
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> new Thread(r, "PlateCases-IO"));
    private YamlConfiguration config;
    private YamlConfiguration messages;

    public ConfigManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.getDataFolder().mkdirs();
        for (String f : DEFAULT_FILES) {
            if (!new File(plugin.getDataFolder(), f).exists()) plugin.saveResource(f, false);
        }
        config = loadWithDefaults("config.yml");
        messages = loadWithDefaults("messages.yml");
    }

    public YamlConfiguration config() {
        return config;
    }

    public YamlConfiguration messages() {
        return messages;
    }

    public File file(String name) {
        return new File(plugin.getDataFolder(), name);
    }

    /** Завантажує файл без дефолтів (для items/chests/loot). */
    public YamlConfiguration loadYaml(String name) {
        return YamlConfiguration.loadConfiguration(file(name));
    }

    private YamlConfiguration loadWithDefaults(String name) {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file(name));
        try (InputStream in = plugin.getResource(name)) {
            if (in != null) {
                y.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)));
            }
        } catch (IOException ex) {
            plugin.getLogger().log(Level.WARNING, "Не вдалося прочитати дефолти " + name, ex);
        }
        return y;
    }

    public void saveConfig() {
        saveYamlAsync("config.yml", config);
    }

    /** Серіалізація — в основному потоці, запис на диск — асинхронно. */
    public void saveYamlAsync(String name, YamlConfiguration yaml) {
        final String data = yaml.saveToString();
        io.execute(() -> write(name, data));
    }

    /** Синхронний запис (для вимкнення плагіна). */
    public void saveYamlNow(String name, YamlConfiguration yaml) {
        write(name, yaml.saveToString());
    }

    public void appendLog(String line) {
        io.execute(() -> {
            try {
                Path p = file("logs/opens.log").toPath();
                Files.createDirectories(p.getParent());
                Files.writeString(p, line + System.lineSeparator(), StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException ex) {
                plugin.getLogger().log(Level.WARNING, "Не вдалося записати лог", ex);
            }
        });
    }

    private void write(String name, String data) {
        try {
            Path target = file(name).toPath();
            Files.createDirectories(target.getParent());
            Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
            Files.writeString(tmp, data, StandardCharsets.UTF_8);
            try {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Не вдалося зберегти " + name, ex);
        }
    }

    /** Чекає завершення всіх запланованих записів. */
    public void flush() {
        try {
            io.submit(() -> { }).get(10, TimeUnit.SECONDS);
        } catch (Exception ignored) {
        }
    }

    public void shutdown() {
        io.shutdown();
        try {
            io.awaitTermination(15, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }
}
