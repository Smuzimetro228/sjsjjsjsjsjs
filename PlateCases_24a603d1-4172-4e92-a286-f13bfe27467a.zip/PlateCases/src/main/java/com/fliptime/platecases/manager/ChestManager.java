package com.fliptime.platecases.manager;

import com.fliptime.platecases.PlateCasesPlugin;
import com.fliptime.platecases.model.ChestData;
import com.fliptime.platecases.model.PlateDef;
import com.fliptime.platecases.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Lidded;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/** Реєстр спеціальних сундуків, їх інвентарі, збереження, ефекти та статистика. */
public class ChestManager {

    /** Власник віртуального інвентаря луту. */
    public static class ChestHolder implements InventoryHolder {
        public final String chestId;
        private Inventory inventory;

        public ChestHolder(String chestId) {
            this.chestId = chestId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final BlockFace[] HORIZONTAL = {BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};

    private final PlateCasesPlugin plugin;
    private final Map<String, ChestData> byId = new LinkedHashMap<>();
    private final Map<String, ChestData> byLoc = new HashMap<>();
    private final Map<String, Inventory> openInv = new HashMap<>();
    private final Map<Integer, Integer> levelStats = new TreeMap<>();
    private final Map<UUID, Integer> playerStats = new HashMap<>();
    private boolean saveScheduled;

    public ChestManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ завантаження / збереження

    public void load() {
        byId.clear();
        byLoc.clear();
        levelStats.clear();
        playerStats.clear();
        YamlConfiguration y = plugin.configs().loadYaml("chests.yml");
        ConfigurationSection cs = y.getConfigurationSection("chests");
        if (cs != null) {
            for (String id : cs.getKeys(false)) {
                ConfigurationSection s = cs.getConfigurationSection(id);
                if (s == null) continue;
                try {
                    UUID wid = UUID.fromString(s.getString("world-uuid", ""));
                    String wname = s.getString("world-name", "");
                    if (Bukkit.getWorld(wid) == null && !wname.isEmpty()) {
                        World w2 = Bukkit.getWorld(wname);
                        if (w2 != null) wid = w2.getUID();
                    }
                    ChestData c = new ChestData(id, wid, wname, s.getInt("x"), s.getInt("y"), s.getInt("z"),
                            ChestData.Type.valueOf(s.getString("type", "CHEST").toUpperCase()));
                    c.level = s.getInt("level", 1);
                    c.opened = s.getBoolean("opened", false);
                    String op = s.getString("opener");
                    if (op != null) {
                        try {
                            c.opener = UUID.fromString(op);
                        } catch (IllegalArgumentException ignored) {
                        }
                    }
                    c.openerName = s.getString("opener-name");
                    c.openedAt = s.getLong("opened-at", 0L);
                    ConfigurationSection cont = s.getConfigurationSection("contents");
                    if (cont != null) {
                        for (String k : cont.getKeys(false)) {
                            ItemStack it = cont.getItemStack(k);
                            if (it != null) c.contents.put(Integer.parseInt(k), it);
                        }
                    }
                    register(c);
                } catch (Exception ex) {
                    plugin.getLogger().warning("chests.yml: не вдалося завантажити запис " + id + ": " + ex.getMessage());
                }
            }
        }
        ConfigurationSection lv = y.getConfigurationSection("stats.levels");
        if (lv != null) for (String k : lv.getKeys(false)) levelStats.put(Integer.parseInt(k), lv.getInt(k));
        ConfigurationSection pl = y.getConfigurationSection("stats.players");
        if (pl != null) {
            for (String k : pl.getKeys(false)) {
                try {
                    playerStats.put(UUID.fromString(k), pl.getInt(k));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    private YamlConfiguration toYaml() {
        YamlConfiguration y = new YamlConfiguration();
        y.createSection("chests");
        for (ChestData c : byId.values()) {
            String p = "chests." + c.id + ".";
            y.set(p + "world-uuid", c.worldId.toString());
            y.set(p + "world-name", c.worldName);
            y.set(p + "x", c.x);
            y.set(p + "y", c.y);
            y.set(p + "z", c.z);
            y.set(p + "type", c.type.name());
            y.set(p + "level", c.level);
            y.set(p + "opened", c.opened);
            if (c.opener != null) y.set(p + "opener", c.opener.toString());
            if (c.openerName != null) y.set(p + "opener-name", c.openerName);
            y.set(p + "opened-at", c.openedAt);
            for (Map.Entry<Integer, ItemStack> e : c.contents.entrySet()) {
                y.set(p + "contents." + e.getKey(), e.getValue());
            }
        }
        for (Map.Entry<Integer, Integer> e : levelStats.entrySet()) y.set("stats.levels." + e.getKey(), e.getValue());
        for (Map.Entry<UUID, Integer> e : playerStats.entrySet()) y.set("stats.players." + e.getKey(), e.getValue());
        return y;
    }

    public void save() {
        plugin.configs().saveYamlAsync("chests.yml", toYaml());
    }

    /** Відкладене (debounce) асинхронне збереження. */
    public void markDirty() {
        if (saveScheduled || !plugin.isEnabled()) return;
        saveScheduled = true;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            saveScheduled = false;
            save();
        }, 20L);
    }

    public void shutdown() {
        for (String id : new ArrayList<>(openInv.keySet())) {
            ChestData c = byId.get(id);
            if (c != null) syncContents(c);
        }
        plugin.configs().saveYamlNow("chests.yml", toYaml());
        for (Inventory inv : new ArrayList<>(openInv.values())) {
            for (var v : new ArrayList<>(inv.getViewers())) v.closeInventory();
        }
        openInv.clear();
    }

    // ------------------------------------------------------------------ реєстр

    private void register(ChestData c) {
        byId.put(c.id, c);
        byLoc.put(c.key(), c);
    }

    public ChestData getAt(Block b) {
        if (b == null) return null;
        ChestData c = byLoc.get(ChestData.key(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ()));
        if (c == null || c.type.material != b.getType()) return null;
        return c;
    }

    public ChestData byId(String id) {
        return byId.get(id);
    }

    public Collection<ChestData> all() {
        return Collections.unmodifiableCollection(byId.values());
    }

    public int sizeOf(ChestData.Type t) {
        int v = plugin.configs().config().getInt(t == ChestData.Type.CHEST ? "chests.chest-size" : "chests.barrel-size", 27);
        return Math.max(9, Math.min(54, (v / 9) * 9));
    }

    // ------------------------------------------------------------------ створення / видалення

    /** Ставить спеціальний сундук/бочку у блоці, де стоїть гравець. */
    public boolean place(Player p, ChestData.Type type, int level) {
        if (plugin.plates().byLevel(level) == null) {
            plugin.messages().send(p, "unknown-level");
            return false;
        }
        Block b = p.getLocation().getBlock();
        if (!(b.getType().isAir() || b.isReplaceable())) {
            plugin.messages().send(p, "place-blocked");
            return false;
        }
        if (getAt(b) != null) {
            plugin.messages().send(p, "place-exists");
            return false;
        }
        if (type == ChestData.Type.CHEST) {
            for (BlockFace f : HORIZONTAL) {
                Material m = b.getRelative(f).getType();
                if (m == Material.CHEST || m == Material.TRAPPED_CHEST) {
                    plugin.messages().send(p, "place-adjacent");
                    return false;
                }
            }
        }
        boolean toward = plugin.configs().config().getBoolean("chests.face-player", true);
        BlockFace face;
        float pitch = p.getLocation().getPitch();
        if (type == ChestData.Type.BARREL && pitch >= 60) face = BlockFace.UP;
        else if (type == ChestData.Type.BARREL && pitch <= -60) face = BlockFace.DOWN;
        else face = p.getFacing().getOppositeFace();
        if (!toward) face = face.getOppositeFace();

        b.setType(type.material, false);
        BlockData data = b.getBlockData();
        if (data instanceof org.bukkit.block.data.type.Chest cd) {
            cd.setType(org.bukkit.block.data.type.Chest.Type.SINGLE);
            cd.setFacing(face);
        } else if (data instanceof Directional dir) {
            dir.setFacing(face);
        }
        b.setBlockData(data, false);

        ChestData c = new ChestData("pc-" + UUID.randomUUID().toString().substring(0, 8),
                b.getWorld().getUID(), b.getWorld().getName(), b.getX(), b.getY(), b.getZ(), type);
        c.level = level;
        register(c);
        markDirty();

        // піднімаємо гравця на блок, щоб він не застряг усередині
        Location l = p.getLocation();
        l.setY(b.getY() + 1.0);
        p.teleport(l);

        plugin.messages().send(p, "place-success", "{type}", type == ChestData.Type.CHEST ? "сундук" : "бочку",
                "{level}", level, "{id}", c.id);
        return true;
    }

    public void remove(ChestData c, boolean breakBlock) {
        byId.remove(c.id);
        byLoc.remove(c.key());
        Inventory inv = openInv.remove(c.id);
        if (inv != null) for (var v : new ArrayList<>(inv.getViewers())) v.closeInventory();
        if (breakBlock) {
            Block b = c.block();
            if (b != null && b.getType() == c.type.material) b.setType(Material.AIR, false);
        }
        markDirty();
    }

    // ------------------------------------------------------------------ інвентар луту

    public Inventory inventoryFor(ChestData c) {
        Inventory existing = openInv.get(c.id);
        if (existing != null) return existing;
        int size = sizeOf(c.type);
        PlateDef pd = plugin.plates().byLevel(c.level);
        String title = pd != null ? pd.chestName : "&8Скарбниця";
        ChestHolder holder = new ChestHolder(c.id);
        Inventory inv = Bukkit.createInventory(holder, size, Text.parse(title));
        holder.inventory = inv;
        for (Map.Entry<Integer, ItemStack> e : c.contents.entrySet()) {
            int slot = e.getKey();
            if (slot >= 0 && slot < size) {
                inv.setItem(slot, e.getValue().clone());
            } else {
                inv.addItem(e.getValue().clone());
            }
        }
        openInv.put(c.id, inv);
        return inv;
    }

    public void openFor(Player p, ChestData c) {
        Inventory inv = inventoryFor(c);
        p.openInventory(inv);
        setLid(c, true);
    }

    public void syncContents(ChestData c) {
        Inventory inv = openInv.get(c.id);
        if (inv == null) return;
        c.contents.clear();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack it = inv.getItem(i);
            if (it != null && !it.getType().isAir()) c.contents.put(i, it.clone());
        }
    }

    public void scheduleSync(String chestId) {
        if (!plugin.isEnabled()) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            ChestData c = byId.get(chestId);
            if (c == null) return;
            syncContents(c);
            markDirty();
        });
    }

    public void onClose(String chestId, Inventory inv, Player closer) {
        ChestData c = byId.get(chestId);
        if (c == null) return;
        syncContents(c);
        long others = inv.getViewers().stream().filter(v -> !v.getUniqueId().equals(closer.getUniqueId())).count();
        if (others == 0) {
            String mode = plugin.configs().config().getString("chests.reopen-mode", "ANYONE").toUpperCase();
            if (c.opened && mode.equals("NONE") && !c.contents.isEmpty()) {
                Location loc = c.location();
                if (loc != null) {
                    Location drop = loc.clone().add(0.5, 1.0, 0.5);
                    for (ItemStack it : c.contents.values()) loc.getWorld().dropItemNaturally(drop, it);
                }
                c.contents.clear();
                inv.clear();
            }
            setLid(c, false);
            openInv.remove(c.id);
        }
        markDirty();
    }

    private void setLid(ChestData c, boolean open) {
        try {
            Block b = c.block();
            if (b == null || b.getType() != c.type.material) return;
            BlockState st = b.getState();
            if (st instanceof Lidded l) {
                if (open) l.open();
                else l.close();
            }
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ ефекти, статистика, лог

    public Particle resolveParticle(String name) {
        if (name == null) return null;
        NamespacedKey k = NamespacedKey.fromString(name.toLowerCase());
        return k == null ? null : Registry.PARTICLE_TYPE.get(k);
    }

    public boolean isValidSound(String key) {
        if (key == null) return false;
        NamespacedKey k = NamespacedKey.fromString(key.toLowerCase());
        return k != null && Registry.SOUNDS.get(k) != null;
    }

    public void playEffects(PlateDef d, ChestData c) {
        Location base = c.location();
        if (base == null || d == null) return;
        World w = base.getWorld();
        Location center = base.clone().add(0.5, 1.0, 0.5);
        var cfg = plugin.configs().config();
        if (cfg.getBoolean("effects.sounds-enabled", true) && d.openSound != null && !d.openSound.isBlank()) {
            try {
                w.playSound(center, d.openSound, SoundCategory.BLOCKS, d.soundVolume, d.soundPitch);
            } catch (Exception ex) {
                plugin.getLogger().warning("Невірний звук у пластинки " + d.id + ": " + d.openSound);
            }
        }
        if (!cfg.getBoolean("effects.particles-enabled", true) || !d.particles) return;
        final Particle particle = resolveParticle(d.particle);
        if (particle == null) return;
        try {
            w.spawnParticle(particle, center, d.particleCount, 0.4, 0.4, 0.4, 0.05);
        } catch (Exception ex) {
            plugin.getLogger().warning("Частинка " + d.particle + " потребує додаткових даних і не підтримується.");
            return;
        }
        if (cfg.getBoolean("chests.open-animation", true)) {
            new BukkitRunnable() {
                int t = 0;

                @Override
                public void run() {
                    if (t >= 24) {
                        cancel();
                        return;
                    }
                    double a = t * 0.55;
                    double h = t * 0.04;
                    for (int i = 0; i < 2; i++) {
                        double ang = a + i * Math.PI;
                        Location l = center.clone().add(Math.cos(ang) * 0.8, h, Math.sin(ang) * 0.8);
                        try {
                            w.spawnParticle(particle, l, 2, 0, 0, 0, 0);
                        } catch (Exception ex) {
                            cancel();
                            return;
                        }
                    }
                    t++;
                }
            }.runTaskTimer(plugin, 0L, 1L);
        }
    }

    public void recordOpen(Player p, ChestData c, PlateDef plate) {
        levelStats.merge(c.level, 1, Integer::sum);
        playerStats.merge(p.getUniqueId(), 1, Integer::sum);
        if (plugin.configs().config().getBoolean("settings.log-opens", true)) {
            String line = "[" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + "] "
                    + p.getName() + " (" + p.getUniqueId() + ") відкрив " + c.id + " [" + c.type + ", рівень " + c.level + "] "
                    + "пластинкою " + (plate == null ? "?" : plate.id) + " у " + c.worldName + " " + c.x + " " + c.y + " " + c.z;
            plugin.getLogger().info(line);
            plugin.configs().appendLog(line);
        }
    }

    public int levelOpened(int level) {
        return levelStats.getOrDefault(level, 0);
    }

    public int playerOpened(UUID id) {
        return playerStats.getOrDefault(id, 0);
    }

    public int totalOpened() {
        int s = 0;
        for (int v : levelStats.values()) s += v;
        return s;
    }

    public int countUnused() {
        int n = 0;
        for (ChestData c : byId.values()) if (!c.opened) n++;
        return n;
    }
}
