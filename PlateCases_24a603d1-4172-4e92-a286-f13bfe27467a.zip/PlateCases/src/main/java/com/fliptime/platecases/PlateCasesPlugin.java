package com.fliptime.platecases;

import com.fliptime.platecases.command.PlateCommand;
import com.fliptime.platecases.config.ConfigManager;
import com.fliptime.platecases.gui.GuiManager;
import com.fliptime.platecases.hook.PapiExpansion;
import com.fliptime.platecases.listener.ChestListener;
import com.fliptime.platecases.manager.ChatInputManager;
import com.fliptime.platecases.manager.ChestManager;
import com.fliptime.platecases.manager.LootManager;
import com.fliptime.platecases.manager.PlateManager;
import com.fliptime.platecases.util.Messages;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class PlateCasesPlugin extends JavaPlugin {

    private ConfigManager configs;
    private Messages messages;
    private PlateManager plates;
    private LootManager loot;
    private ChestManager chests;
    private GuiManager gui;
    private ChatInputManager input;

    @Override
    public void onEnable() {
        configs = new ConfigManager(this);
        configs.load();
        messages = new Messages(this);
        plates = new PlateManager(this);
        plates.load();
        loot = new LootManager(this);
        loot.load();
        chests = new ChestManager(this);
        chests.load();
        gui = new GuiManager(this);
        input = new ChatInputManager(this);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new ChestListener(this), this);
        pm.registerEvents(gui, this);
        pm.registerEvents(input, this);

        PlateCommand cmd = new PlateCommand(this);
        PluginCommand pc = getCommand("pcases");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }

        if (pm.isPluginEnabled("PlaceholderAPI")) {
            PapiExpansion.hook(this);
        }
        getLogger().info("PlateCases " + getPluginMeta().getVersion() + " увімкнено. Пластинок: "
                + plates.all().size() + ", сундуків: " + chests.all().size());
    }

    @Override
    public void onDisable() {
        if (chests != null) chests.shutdown();
        if (configs != null) configs.shutdown();
    }

    /** Перезавантаження конфігів (реєстр сундуків лишається в пам'яті — він актуальний). */
    public void reloadAll() {
        configs.flush();
        configs.load();
        plates.load();
        loot.load();
    }

    public ConfigManager configs() { return configs; }
    public Messages messages() { return messages; }
    public PlateManager plates() { return plates; }
    public LootManager loot() { return loot; }
    public ChestManager chests() { return chests; }
    public GuiManager gui() { return gui; }
    public ChatInputManager input() { return input; }
}
