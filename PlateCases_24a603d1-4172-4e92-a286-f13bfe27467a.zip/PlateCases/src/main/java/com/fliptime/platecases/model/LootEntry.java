package com.fliptime.platecases.model;

import org.bukkit.inventory.ItemStack;

/** Один предмет у таблиці луту. */
public class LootEntry {
    public final String id;
    public ItemStack item;
    public double chance = 100.0;
    public int min = 1;
    public int max = 1;

    public LootEntry(String id, ItemStack item) {
        this.id = id;
        this.item = item;
    }
}
