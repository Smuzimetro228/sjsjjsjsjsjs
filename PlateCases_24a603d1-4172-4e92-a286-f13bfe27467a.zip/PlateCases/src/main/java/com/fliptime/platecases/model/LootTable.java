package com.fliptime.platecases.model;

import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/** Таблиця луту одного рівня. */
public class LootTable {
    public final int level;
    public int rolls = 1;
    public final List<LootEntry> entries = new ArrayList<>();

    public LootTable(int level) {
        this.level = level;
    }

    public LootEntry find(String id) {
        if (id == null) return null;
        for (LootEntry e : entries) if (e.id.equals(id)) return e;
        return null;
    }

    /**
     * Генерує лут: кожен предмет потрапляє у випадковий унікальний слот.
     * За кожен "рол" перевіряється шанс кожного предмета; порядок предметів випадковий.
     */
    public Map<Integer, ItemStack> generate(int size) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        List<Integer> free = new ArrayList<>(size);
        for (int i = 0; i < size; i++) free.add(i);
        Collections.shuffle(free, r);

        Map<Integer, ItemStack> out = new LinkedHashMap<>();
        for (int roll = 0; roll < Math.max(1, rolls) && !free.isEmpty(); roll++) {
            List<LootEntry> order = new ArrayList<>(entries);
            Collections.shuffle(order, r);
            for (LootEntry e : order) {
                if (free.isEmpty()) break;
                if (e.item == null || e.item.getType().isAir()) continue;
                if (r.nextDouble() * 100.0 >= e.chance) continue;
                int lo = Math.max(1, e.min);
                int hi = Math.max(lo, e.max);
                int amount = lo == hi ? lo : r.nextInt(lo, hi + 1);
                int stack = Math.max(1, e.item.getMaxStackSize());
                while (amount > 0 && !free.isEmpty()) {
                    int n = Math.min(amount, stack);
                    ItemStack it = e.item.clone();
                    it.setAmount(n);
                    out.put(free.remove(free.size() - 1), it);
                    amount -= n;
                }
            }
        }
        return out;
    }
}
