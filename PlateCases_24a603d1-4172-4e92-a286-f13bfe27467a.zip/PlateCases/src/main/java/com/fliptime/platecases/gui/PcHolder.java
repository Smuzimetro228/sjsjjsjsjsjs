package com.fliptime.platecases.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Власник усіх адмін-меню PlateCases (захист від сторонніх змін). */
public class PcHolder implements InventoryHolder {

    public enum Type { MAIN, PLATE, LOOT, ENTRY, CHESTS, SETTINGS, STATS }

    public final Type type;
    public String plateId;
    public String entryId;
    public int level;
    public int page;
    public boolean readOnly;
    public Inventory inventory;

    public PcHolder(Type type) {
        this.type = type;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
