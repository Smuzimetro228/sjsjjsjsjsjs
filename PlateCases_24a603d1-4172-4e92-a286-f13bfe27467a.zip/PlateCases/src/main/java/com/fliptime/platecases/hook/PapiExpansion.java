package com.fliptime.platecases.hook;

import com.fliptime.platecases.PlateCasesPlugin;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

/**
 * PlaceholderAPI:
 * %platecases_opened% — скільки сундуків відкрив гравець;
 * %platecases_opened_total% — всього відкрито;
 * %platecases_opened_level_N% — відкрито сундуків рівня N;
 * %platecases_chests_total% / _used% / _unused% — кількість сундуків.
 */
public class PapiExpansion extends PlaceholderExpansion {

    private final PlateCasesPlugin plugin;

    public PapiExpansion(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    public static void hook(PlateCasesPlugin plugin) {
        new PapiExpansion(plugin).register();
    }

    @Override
    public @NotNull String getIdentifier() {
        return "platecases";
    }

    @Override
    public @NotNull String getAuthor() {
        return "FlipTime";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        var cm = plugin.chests();
        switch (params.toLowerCase()) {
            case "opened":
                return player == null ? "0" : String.valueOf(cm.playerOpened(player.getUniqueId()));
            case "opened_total":
                return String.valueOf(cm.totalOpened());
            case "chests_total":
                return String.valueOf(cm.all().size());
            case "chests_unused":
                return String.valueOf(cm.countUnused());
            case "chests_used":
                return String.valueOf(cm.all().size() - cm.countUnused());
            default:
                break;
        }
        if (params.toLowerCase().startsWith("opened_level_")) {
            try {
                return String.valueOf(cm.levelOpened(Integer.parseInt(params.substring("opened_level_".length()))));
            } catch (NumberFormatException ex) {
                return null;
            }
        }
        return null;
    }
}
