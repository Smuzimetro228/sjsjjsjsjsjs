package com.fliptime.platecases.manager;

import com.fliptime.platecases.PlateCasesPlugin;
import com.fliptime.platecases.model.LootEntry;
import com.fliptime.platecases.model.LootTable;
import com.fliptime.platecases.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.io.File;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/** Таблиці луту: loot/levelN.yml. */
public class LootManager {

    private final PlateCasesPlugin plugin;
    private final Map<Integer, LootTable> tables = new TreeMap<>();

    public LootManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        tables.clear();
        File dir = plugin.configs().file("loot");
        File[] files = dir.listFiles((d, n) -> n.matches("level\\d+\\.yml"));
        if (files == null) return;
        for (File f : files) {
            String n = f.getName();
            int level = Integer.parseInt(n.substring(5, n.length() - 4));
            tables.put(level, parse(level, YamlConfiguration.loadConfiguration(f)));
        }
    }

    private LootTable parse(int level, YamlConfiguration y) {
        LootTable t = new LootTable(level);
        t.rolls = Math.max(1, y.getInt("rolls", 1));
        ConfigurationSection es = y.getConfigurationSection("entries");
        if (es == null) return t;
        for (String id : es.getKeys(false)) {
            ConfigurationSection s = es.getConfigurationSection(id);
            if (s == null) continue;
            ItemStack item = null;
            Object o = s.get("item");
            if (o instanceof ItemStack is) item = is;
            else item = simple(s);
            if (item == null || item.getType().isAir()) {
                plugin.getLogger().warning("loot/level" + level + ".yml: запис '" + id + "' пропущено (невірний предмет)");
                continue;
            }
            LootEntry e = new LootEntry(id, item);
            e.chance = Math.max(0, Math.min(100, s.getDouble("chance", 100.0)));
            e.min = Math.max(1, s.getInt("min", 1));
            e.max = Math.max(e.min, s.getInt("max", e.min));
            t.entries.add(e);
        }
        return t;
    }

    /** Простий формат: material (+ potion, name). */
    private ItemStack simple(ConfigurationSection s) {
        Material m = Material.matchMaterial(s.getString("material", ""));
        if (m == null || !m.isItem() || m.isAir()) return null;
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        String name = s.getString("name");
        if (name != null) meta.displayName(Text.item(name));
        String potion = s.getString("potion");
        if (potion != null && meta instanceof PotionMeta pm) {
            NamespacedKey k = NamespacedKey.fromString(potion.toLowerCase());
            PotionType type = k == null ? null : Registry.POTION.get(k);
            if (type != null) pm.setBasePotionType(type);
        }
        it.setItemMeta(meta);
        return it;
    }

    public LootTable table(int level) {
        LootTable t = tables.get(level);
        if (t == null) {
            t = new LootTable(level);
            tables.put(level, t);
            save(t);
        }
        return t;
    }

    public void save(LootTable t) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("rolls", t.rolls);
        for (LootEntry e : t.entries) {
            String p = "entries." + e.id + ".";
            y.set(p + "item", e.item);
            y.set(p + "chance", e.chance);
            y.set(p + "min", e.min);
            y.set(p + "max", e.max);
        }
        plugin.configs().saveYamlAsync("loot/level" + t.level + ".yml", y);
    }

    public String newEntryId() {
        return UUID.randomUUID().toString().substring(0, 8);
    }
}
