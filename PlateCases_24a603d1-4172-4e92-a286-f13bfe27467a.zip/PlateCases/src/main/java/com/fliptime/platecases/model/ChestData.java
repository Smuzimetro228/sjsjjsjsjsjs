package com.fliptime.platecases.model;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/** Зареєстрований спеціальний сундук/бочка. */
public class ChestData {

    public enum Type {
        CHEST(Material.CHEST), BARREL(Material.BARREL);

        public final Material material;

        Type(Material material) {
            this.material = material;
        }
    }

    public final String id;
    public final UUID worldId;
    public final String worldName;
    public final int x, y, z;
    public final Type type;
    public int level = 1;
    public boolean opened;
    public UUID opener;
    public String openerName;
    public long openedAt;
    public final Map<Integer, ItemStack> contents = new TreeMap<>();

    public ChestData(String id, UUID worldId, String worldName, int x, int y, int z, Type type) {
        this.id = id;
        this.worldId = worldId;
        this.worldName = worldName;
        this.x = x;
        this.y = y;
        this.z = z;
        this.type = type;
    }

    public static String key(UUID world, int x, int y, int z) {
        return world + ";" + x + ";" + y + ";" + z;
    }

    public String key() {
        return key(worldId, x, y, z);
    }

    public Location location() {
        World w = Bukkit.getWorld(worldId);
        return w == null ? null : new Location(w, x, y, z);
    }

    public Block block() {
        Location l = location();
        return l == null ? null : l.getBlock();
    }
}
