package com.fliptime.platecases.util;

import com.fliptime.platecases.PlateCasesPlugin;
import net.kyori.adventure.text.Component;
import org.bukkit.command.CommandSender;

import java.util.List;

/** Повідомлення з messages.yml. */
public class Messages {

    private final PlateCasesPlugin plugin;

    public Messages(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    public String raw(String key) {
        String s = plugin.configs().messages().getString(key);
        return s == null ? "&cNo message: " + key : s;
    }

    public String format(String key, Object... kv) {
        String s = raw(key).replace("{prefix}", plugin.configs().messages().getString("prefix", ""));
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace(String.valueOf(kv[i]), String.valueOf(kv[i + 1]));
        }
        return s;
    }

    public Component get(String key, Object... kv) {
        return Text.parse(format(key, kv));
    }

    public void send(CommandSender to, String key, Object... kv) {
        if (raw(key).isEmpty()) return;
        to.sendMessage(get(key, kv));
    }

    public void sendList(CommandSender to, String key) {
        List<String> lines = plugin.configs().messages().getStringList(key);
        for (String l : lines) to.sendMessage(Text.parse(l));
    }
}
