package com.fliptime.platecases.listener;

import com.fliptime.platecases.PlateCasesPlugin;
import com.fliptime.platecases.manager.ChestManager;
import com.fliptime.platecases.manager.ChestManager.ChestHolder;
import com.fliptime.platecases.model.ChestData;
import com.fliptime.platecases.model.LootTable;
import com.fliptime.platecases.model.PlateDef;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Відкриття сундуків пластинками + захист спеціальних блоків та інвентарів. */
public class ChestListener implements Listener {

    private static final BlockFace[] HORIZONTAL = {BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};

    private final PlateCasesPlugin plugin;
    private final Map<UUID, Long> cooldown = new HashMap<>();

    public ChestListener(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    private ChestManager cm() {
        return plugin.chests();
    }

    // ------------------------------------------------------------------ відкриття

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block b = e.getClickedBlock();
        if (b == null) return;
        Player p = e.getPlayer();
        ChestData cd = cm().getAt(b);

        if (cd == null) {
            // пластинки — музичні диски: не даємо вставити їх у програвач
            if (b.getType() == Material.JUKEBOX && plugin.plates().isTagged(e.getItem())) {
                e.setCancelled(true);
                plugin.messages().send(p, "plate-not-usable");
            }
            return;
        }

        e.setCancelled(true); // ванільне відкриття завжди заборонене
        if (e.getHand() != EquipmentSlot.HAND) return;

        long now = System.currentTimeMillis();
        long cdMs = plugin.configs().config().getLong("settings.open-cooldown-ms", 400L);
        Long last = cooldown.get(p.getUniqueId());
        if (last != null && now - last < cdMs) return;
        cooldown.put(p.getUniqueId(), now);

        PlayerInventory inv = p.getInventory();
        ItemStack hand = inv.getItemInMainHand();
        boolean tagged = plugin.plates().isTagged(hand);

        // --- сундук вже відкривався
        if (cd.opened) {
            if (tagged) {
                plugin.messages().send(p, "already-used"); // пластинка НЕ витрачається
                return;
            }
            String mode = plugin.configs().config().getString("chests.reopen-mode", "ANYONE").toUpperCase();
            switch (mode) {
                case "NONE" -> plugin.messages().send(p, "already-used");
                case "OPENER" -> {
                    boolean own = cd.opener != null && cd.opener.equals(p.getUniqueId());
                    if (own || p.hasPermission("platecases.admin")) cm().openFor(p, cd);
                    else plugin.messages().send(p, "already-used-other");
                }
                default -> cm().openFor(p, cd);
            }
            return;
        }

        // --- перевірки ДО витрачання пластинки
        if (!p.hasPermission("platecases.use")) {
            plugin.messages().send(p, "no-permission");
            return;
        }
        if (!tagged) {
            if (plugin.plates().isTagged(inv.getItemInOffHand())) plugin.messages().send(p, "plate-offhand");
            else plugin.messages().send(p, "hold-plate");
            return;
        }
        PlateDef plate = plugin.plates().identify(hand);
        if (plate == null) {
            plugin.messages().send(p, "fake-plate");
            return;
        }
        if (plate.level != cd.level) {
            plugin.messages().send(p, "wrong-level");
            return;
        }
        LootTable table = plugin.loot().table(cd.level);
        if (table.entries.isEmpty()) {
            plugin.messages().send(p, "loot-empty");
            return;
        }

        // --- генерація луту (один раз) і витрата пластинки
        var loot = table.generate(cm().sizeOf(cd.type));
        if (!consumeOne(p)) return;

        cd.opened = true;
        cd.opener = p.getUniqueId();
        cd.openerName = p.getName();
        cd.openedAt = System.currentTimeMillis();
        cd.contents.clear();
        cd.contents.putAll(loot);

        cm().recordOpen(p, cd, plate);
        cm().save(); // результат відкриття фіксуємо одразу (асинхронний запис)
        cm().openFor(p, cd);
        cm().playEffects(plate, cd);
        plugin.messages().send(p, "opened", "{plate}", plate.name);
    }

    /** Забирає рівно одну справжню пластинку з основної руки. */
    private boolean consumeOne(Player p) {
        PlayerInventory inv = p.getInventory();
        ItemStack cur = inv.getItemInMainHand();
        if (plugin.plates().identify(cur) == null) return false;
        if (cur.getAmount() <= 1) {
            inv.setItemInMainHand(null);
        } else {
            ItemStack copy = cur.clone();
            copy.setAmount(cur.getAmount() - 1);
            inv.setItemInMainHand(copy);
        }
        return true;
    }

    // ------------------------------------------------------------------ захист блоків

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (cm().getAt(e.getBlock()) != null) {
            e.setCancelled(true);
            plugin.messages().send(e.getPlayer(), "break-denied");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> cm().getAt(b) != null);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> cm().getAt(b) != null);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityChange(EntityChangeBlockEvent e) {
        if (cm().getAt(e.getBlock()) != null) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (cm().getAt(b) != null) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) {
            if (cm().getAt(b) != null) {
                e.setCancelled(true);
                return;
            }
        }
    }

    /** Не дозволяємо утворити подвійний сундук зі спеціальним. */
    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Material m = e.getBlockPlaced().getType();
        if (m != Material.CHEST && m != Material.TRAPPED_CHEST) return;
        for (BlockFace f : HORIZONTAL) {
            if (cm().getAt(e.getBlockPlaced().getRelative(f)) != null) {
                e.setCancelled(true);
                plugin.messages().send(e.getPlayer(), "adjacent-denied");
                return;
            }
        }
    }

    /** Лійки не повинні ні забирати, ні класти предмети у спеціальні контейнери. */
    @EventHandler(ignoreCancelled = true)
    public void onMove(InventoryMoveItemEvent e) {
        if (isSpecial(e.getSource()) || isSpecial(e.getDestination())) e.setCancelled(true);
    }

    private boolean isSpecial(Inventory inv) {
        if (inv.getHolder(false) instanceof ChestHolder) return true;
        Location l = inv.getLocation();
        return l != null && cm().getAt(l.getBlock()) != null;
    }

    // ------------------------------------------------------------------ інвентар луту

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof ChestHolder h)) return;
        if (!plugin.configs().config().getBoolean("chests.allow-put-items", false)) {
            boolean clickedTop = e.getClickedInventory() == top;
            InventoryAction a = e.getAction();
            ClickType ct = e.getClick();
            if (!clickedTop) {
                if (a == InventoryAction.MOVE_TO_OTHER_INVENTORY) e.setCancelled(true);
            } else {
                if (a == InventoryAction.PLACE_ALL || a == InventoryAction.PLACE_ONE
                        || a == InventoryAction.PLACE_SOME || a == InventoryAction.SWAP_WITH_CURSOR) {
                    e.setCancelled(true);
                } else if (ct == ClickType.NUMBER_KEY || ct == ClickType.SWAP_OFFHAND) {
                    ItemStack src = null;
                    if (e.getWhoClicked() instanceof Player p) {
                        src = ct == ClickType.SWAP_OFFHAND
                                ? p.getInventory().getItemInOffHand()
                                : (e.getHotbarButton() >= 0 ? p.getInventory().getItem(e.getHotbarButton()) : null);
                    }
                    if (src != null && !src.getType().isAir()) e.setCancelled(true);
                }
            }
        }
        cm().scheduleSync(h.chestId);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof ChestHolder h)) return;
        if (!plugin.configs().config().getBoolean("chests.allow-put-items", false)) {
            for (int slot : e.getRawSlots()) {
                if (slot < top.getSize()) {
                    e.setCancelled(true);
                    return;
                }
            }
        }
        cm().scheduleSync(h.chestId);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof ChestHolder h)) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        cm().onClose(h.chestId, e.getInventory(), p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        cooldown.remove(e.getPlayer().getUniqueId());
    }
}
