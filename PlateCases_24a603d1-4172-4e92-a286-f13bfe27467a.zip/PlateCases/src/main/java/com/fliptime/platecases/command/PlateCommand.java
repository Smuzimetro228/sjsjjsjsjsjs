package com.fliptime.platecases.command;

import com.fliptime.platecases.PlateCasesPlugin;
import com.fliptime.platecases.model.ChestData;
import com.fliptime.platecases.model.PlateDef;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PlateCommand implements CommandExecutor, TabCompleter {

    private static final int PAGE_SIZE = 10;
    private final PlateCasesPlugin plugin;

    public PlateCommand(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("platecases.admin")) {
            plugin.messages().send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            plugin.messages().sendList(sender, "help");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "menu" -> {
                if (!(sender instanceof Player p)) {
                    plugin.messages().send(sender, "players-only");
                    return true;
                }
                plugin.gui().openMain(p);
            }
            case "place" -> place(sender, args);
            case "give" -> give(sender, args);
            case "reload" -> {
                plugin.reloadAll();
                plugin.messages().send(sender, "reloaded");
            }
            case "remove" -> remove(sender, args);
            case "list" -> list(sender, args);
            case "tp" -> tp(sender, args);
            default -> plugin.messages().sendList(sender, "help");
        }
        return true;
    }

    private void place(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.messages().send(sender, "players-only");
            return;
        }
        if (args.length < 2) {
            plugin.messages().send(sender, "usage-place");
            return;
        }
        ChestData.Type type;
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "chest" -> type = ChestData.Type.CHEST;
            case "barrel" -> type = ChestData.Type.BARREL;
            default -> {
                plugin.messages().send(sender, "usage-place");
                return;
            }
        }
        int level;
        if (args.length >= 3) {
            try {
                level = Integer.parseInt(args[2]);
            } catch (NumberFormatException ex) {
                plugin.messages().send(sender, "usage-place");
                return;
            }
        } else {
            level = plugin.plates().all().isEmpty() ? 1 : plugin.plates().all().iterator().next().level;
        }
        plugin.chests().place(p, type, level);
    }

    private void give(CommandSender sender, String[] args) {
        if (args.length < 2) {
            plugin.messages().send(sender, "usage-give");
            return;
        }
        PlateDef d = plugin.plates().get(args[1]);
        Player target;
        int amountIdx;
        if (d != null) {
            if (!(sender instanceof Player p)) {
                plugin.messages().send(sender, "usage-give");
                return;
            }
            target = p;
            amountIdx = 2;
        } else {
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                plugin.messages().send(sender, "player-not-found");
                return;
            }
            if (args.length < 3) {
                plugin.messages().send(sender, "usage-give");
                return;
            }
            d = plugin.plates().get(args[2]);
            if (d == null) {
                plugin.messages().send(sender, "plate-not-found");
                return;
            }
            amountIdx = 3;
        }
        int amount = 1;
        if (args.length > amountIdx) {
            try {
                amount = Integer.parseInt(args[amountIdx]);
            } catch (NumberFormatException ex) {
                plugin.messages().send(sender, "usage-give");
                return;
            }
        }
        amount = Math.max(1, Math.min(amount, 256));
        plugin.plates().giveTo(target, d, amount);
        plugin.messages().send(sender, "plate-given", "{amount}", amount, "{plate}", d.name, "{player}", target.getName());
        if (!target.equals(sender)) plugin.messages().send(target, "plate-received", "{amount}", amount, "{plate}", d.name);
    }

    private void remove(CommandSender sender, String[] args) {
        ChestData c = null;
        if (args.length >= 2) {
            c = plugin.chests().byId(args[1]);
        } else if (sender instanceof Player p) {
            Block b = p.getTargetBlockExact(6);
            c = plugin.chests().getAt(b);
        } else {
            plugin.messages().send(sender, "players-only");
            return;
        }
        if (c == null) {
            plugin.messages().send(sender, "remove-not-found");
            return;
        }
        plugin.chests().remove(c, true);
        plugin.messages().send(sender, "remove-success", "{id}", c.id);
    }

    private void list(CommandSender sender, String[] args) {
        List<ChestData> all = new ArrayList<>(plugin.chests().all());
        if (all.isEmpty()) {
            plugin.messages().send(sender, "list-empty");
            return;
        }
        int pages = (all.size() + PAGE_SIZE - 1) / PAGE_SIZE;
        int page = 1;
        if (args.length >= 2) {
            try {
                page = Integer.parseInt(args[1]);
            } catch (NumberFormatException ignored) {
            }
        }
        page = Math.max(1, Math.min(page, pages));
        plugin.messages().send(sender, "list-header", "{page}", page, "{pages}", pages, "{total}", all.size());
        for (int i = (page - 1) * PAGE_SIZE; i < Math.min(all.size(), page * PAGE_SIZE); i++) {
            ChestData c = all.get(i);
            plugin.messages().send(sender, "list-line", "{id}", c.id, "{world}", c.worldName,
                    "{x}", c.x, "{y}", c.y, "{z}", c.z, "{level}", c.level,
                    "{state}", c.opened ? "&cвідкрито" : "&aне відкрито");
        }
    }

    private void tp(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.messages().send(sender, "players-only");
            return;
        }
        ChestData c = args.length >= 2 ? plugin.chests().byId(args[1]) : null;
        Location l = c == null ? null : c.location();
        if (l == null) {
            plugin.messages().send(sender, "remove-not-found");
            return;
        }
        p.teleport(l.add(0.5, 1.0, 0.5));
        plugin.messages().send(sender, "tp-success", "{id}", c.id);
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("platecases.admin")) return out;
        if (args.length == 1) {
            for (String s : List.of("menu", "place", "give", "reload", "remove", "list", "tp")) add(out, s, args[0]);
        } else if (args.length == 2) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "place" -> {
                    add(out, "chest", args[1]);
                    add(out, "barrel", args[1]);
                }
                case "give" -> {
                    for (PlateDef d : plugin.plates().all()) add(out, d.id, args[1]);
                    for (Player p : Bukkit.getOnlinePlayers()) add(out, p.getName(), args[1]);
                }
                case "remove", "tp" -> {
                    for (ChestData c : plugin.chests().all()) add(out, c.id, args[1]);
                }
                default -> { }
            }
        } else if (args.length == 3) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "give" -> {
                    for (PlateDef d : plugin.plates().all()) add(out, d.id, args[2]);
                }
                case "place" -> {
                    for (PlateDef d : plugin.plates().all()) add(out, String.valueOf(d.level), args[2]);
                }
                default -> { }
            }
        }
        return out;
    }

    private void add(List<String> out, String candidate, String prefix) {
        if (candidate.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))) out.add(candidate);
    }
}
