package com.fliptime.platecases.gui;

import com.fliptime.platecases.PlateCasesPlugin;
import com.fliptime.platecases.model.ChestData;
import com.fliptime.platecases.model.LootEntry;
import com.fliptime.platecases.model.LootTable;
import com.fliptime.platecases.model.PlateDef;
import com.fliptime.platecases.util.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.SoundCategory;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Усі GUI: головне меню, редактор пластинки, редактор луту, створення сундуків, налаштування, статистика. */
public class GuiManager implements Listener {

    private static final int[] PLATE_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
    private static final int[] CH_SLOTS = {10, 11, 15, 16};
    private static final int[] CH_DELTA = {-5, -1, 1, 5};
    private static final int[] MIN_SLOTS = {19, 20, 24, 25};
    private static final int[] MAX_SLOTS = {28, 29, 33, 34};
    private static final int[] Q_DELTA = {-8, -1, 1, 8};

    private final PlateCasesPlugin plugin;

    public GuiManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    // ================================================================== допоміжне

    private ItemStack icon(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Text.item(name));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(Text.item(s));
            meta.lore(l);
        }
        it.setItemMeta(meta);
        return it;
    }

    private void fill(Inventory inv) {
        ItemStack f = icon(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, f);
    }

    private static String num(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    private static int indexOf(int[] arr, int v) {
        for (int i = 0; i < arr.length; i++) if (arr[i] == v) return i;
        return -1;
    }

    private static Integer parseInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private static Double parseDouble(String s) {
        try {
            return Double.parseDouble(s.trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private String onOff(boolean b) {
        return b ? "&aУвімкнено" : "&cВимкнено";
    }

    private void open(Player p, PcHolder h, int size, String title) {
        Inventory inv = Bukkit.createInventory(h, size, Text.parse(title));
        h.inventory = inv;
        render(h);
        p.openInventory(inv);
    }

    private void render(PcHolder h) {
        switch (h.type) {
            case MAIN -> renderMain(h);
            case PLATE -> renderPlate(h);
            case LOOT -> renderLoot(h);
            case ENTRY -> renderEntry(h);
            case CHESTS -> renderChests(h);
            case SETTINGS -> renderSettings(h);
            case STATS -> renderStats(h);
        }
    }

    private void invalid(Player p) {
        plugin.messages().send(p, "input-invalid");
    }

    // ================================================================== відкриття меню

    public void openMain(Player p) {
        open(p, new PcHolder(PcHolder.Type.MAIN), 54, "&8PlateCases » Меню");
    }

    private void openPlate(Player p, String plateId) {
        PcHolder h = new PcHolder(PcHolder.Type.PLATE);
        h.plateId = plateId;
        open(p, h, 36, "&8Пластинка » " + plateId);
    }

    private void openLoot(Player p, int level, String plateId, boolean readOnly) {
        PcHolder h = new PcHolder(PcHolder.Type.LOOT);
        h.level = level;
        h.plateId = plateId;
        h.readOnly = readOnly;
        open(p, h, 54, "&8Лут » Рівень " + level + (readOnly ? " (перегляд)" : ""));
    }

    private void openEntry(Player p, PcHolder from, String entryId) {
        PcHolder h = new PcHolder(PcHolder.Type.ENTRY);
        h.level = from.level;
        h.plateId = from.plateId;
        h.entryId = entryId;
        open(p, h, 45, "&8Предмет » Рівень " + from.level);
    }

    private void openChests(Player p) {
        open(p, new PcHolder(PcHolder.Type.CHESTS), 27, "&8Створення сундуків");
    }

    private void openSettings(Player p) {
        open(p, new PcHolder(PcHolder.Type.SETTINGS), 27, "&8Налаштування");
    }

    private void openStats(Player p) {
        open(p, new PcHolder(PcHolder.Type.STATS), 27, "&8Статистика");
    }

    // ================================================================== головне меню

    private void renderMain(PcHolder h) {
        Inventory inv = h.inventory;
        fill(inv);
        int i = 0;
        for (PlateDef d : plugin.plates().all()) {
            if (i >= PLATE_SLOTS.length) break;
            ItemStack it = plugin.plates().create(d, 1, false);
            ItemMeta m = it.getItemMeta();
            List<Component> lore = new ArrayList<>();
            lore.add(Text.item("&7ID: &f" + d.id));
            lore.add(Text.item("&7Рівень: &e" + d.level));
            lore.add(Text.item("&7Матеріал: &f" + d.material.name()));
            lore.add(Component.empty());
            lore.add(Text.item("&aКлік — редагувати"));
            m.lore(lore);
            it.setItemMeta(m);
            inv.setItem(PLATE_SLOTS[i++], it);
        }
        inv.setItem(46, icon(Material.CHEST, "&6Створення сундуків", "&7Поставити спеціальний сундук", "&7або бочку на вашому місці"));
        inv.setItem(48, icon(Material.WRITABLE_BOOK, "&aСтворити нову пластинку", "&7Новий рівень пластинки"));
        inv.setItem(50, icon(Material.COMPARATOR, "&bНалаштування", "&7Звуки, частинки, логування..."));
        inv.setItem(52, icon(Material.BOOK, "&dСтатистика", "&7Використання пластинок"));
    }

    private void clickMain(Player p, PcHolder h, int slot) {
        List<PlateDef> list = new ArrayList<>(plugin.plates().all());
        int idx = indexOf(PLATE_SLOTS, slot);
        if (idx >= 0 && idx < list.size()) {
            openPlate(p, list.get(idx).id);
            return;
        }
        switch (slot) {
            case 46 -> openChests(p);
            case 48 -> plugin.input().ask(p, "ID нової пластинки (a-z, 0-9, _)", t -> {
                String id = t.toLowerCase();
                if (!id.matches("[a-z0-9_]{2,32}")) {
                    plugin.messages().send(p, "gui-id-invalid");
                    openMain(p);
                    return;
                }
                if (plugin.plates().get(id) != null) {
                    plugin.messages().send(p, "gui-id-exists");
                    openMain(p);
                    return;
                }
                plugin.plates().createNew(id);
                plugin.messages().send(p, "gui-plate-created", "{id}", id);
                openPlate(p, id);
            });
            case 50 -> openSettings(p);
            case 52 -> openStats(p);
            default -> { }
        }
    }

    // ================================================================== редактор пластинки

    private void renderPlate(PcHolder h) {
        PlateDef d = plugin.plates().get(h.plateId);
        Inventory inv = h.inventory;
        fill(inv);
        if (d == null) return;
        inv.setItem(4, plugin.plates().create(d, 1, false));
        inv.setItem(10, icon(Material.NAME_TAG, "&eНазва пластинки", "&7Поточна: &r" + d.name, "", "&aКлік — змінити (чат)"));
        inv.setItem(11, icon(d.material, "&eМатеріал / текстура", "&7Поточний: &f" + d.material.name(), "",
                "&aВізьміть предмет в основну руку", "&aта клікніть тут"));
        inv.setItem(12, icon(Material.PAINTING, "&eCustomModelData", "&7Поточне: &f" + d.customModelData
                + (d.customModelData == 0 ? " &8(вимкнено)" : ""), "", "&aКлік — змінити (чат, 0 = вимкнути)"));
        inv.setItem(13, icon(Material.EXPERIENCE_BOTTLE, "&eРівень пластинки: &f" + d.level, "&7Визначає, до якого сундука", "&7підходить пластинка", "", "&aКлік — змінити (чат)"));
        inv.setItem(14, icon(Material.CHEST, "&eНазва сундука", "&7Поточна: &r" + d.chestName, "", "&aКлік — змінити (чат)"));
        inv.setItem(15, icon(Material.NOTE_BLOCK, "&eЗвук відкриття", "&7Поточний: &f" + d.openSound, "",
                "&aЛКМ — змінити (чат)", "&6ПКМ — прослухати"));
        inv.setItem(16, icon(Material.BLAZE_POWDER, "&eЧастинки: " + onOff(d.particles), "&7Тип: &f" + d.particle, "",
                "&aЛКМ — увімк./вимк.", "&6ПКМ — змінити тип (чат)"));
        inv.setItem(19, icon(Material.ENDER_CHEST, "&6Редактор луту", "&7Предмети, шанси, кількість, ролли"));
        inv.setItem(20, icon(Material.BOOK, "&bПереглянути лут", "&7Лише перегляд"));
        inv.setItem(22, icon(Material.PAPER, "&dСтатистика", "&7Відкрито сундуків цього рівня: &f" + plugin.chests().levelOpened(d.level)));
        inv.setItem(24, icon(d.material, "&aВидати собі", "&7Клік — отримати 1 пластинку"));
        inv.setItem(31, icon(Material.ARROW, "&cНазад"));
    }

    private void clickPlate(Player p, PcHolder h, int slot, ClickType ct) {
        PlateDef d = plugin.plates().get(h.plateId);
        if (d == null) {
            openMain(p);
            return;
        }
        switch (slot) {
            case 10 -> plugin.input().ask(p, "нова назва (&-коди, &#RRGGBB, MiniMessage)", t -> {
                d.name = t;
                plugin.plates().save();
                plugin.messages().send(p, "gui-saved");
                openPlate(p, d.id);
            });
            case 11 -> {
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType().isAir()) {
                    plugin.messages().send(p, "gui-no-item");
                    return;
                }
                d.material = hand.getType();
                plugin.plates().save();
                render(h);
            }
            case 12 -> plugin.input().ask(p, "CustomModelData (ціле число ≥ 0)", t -> {
                Integer v = parseInt(t);
                if (v == null || v < 0) invalid(p);
                else {
                    d.customModelData = v;
                    plugin.plates().save();
                    plugin.messages().send(p, "gui-saved");
                }
                openPlate(p, d.id);
            });
            case 13 -> plugin.input().ask(p, "рівень пластинки (ціле число ≥ 1)", t -> {
                Integer v = parseInt(t);
                if (v == null || v < 1) invalid(p);
                else {
                    d.level = v;
                    plugin.loot().table(v);
                    plugin.plates().save();
                    plugin.messages().send(p, "gui-saved");
                }
                openPlate(p, d.id);
            });
            case 14 -> plugin.input().ask(p, "нова назва сундука", t -> {
                d.chestName = t;
                plugin.plates().save();
                plugin.messages().send(p, "gui-saved");
                openPlate(p, d.id);
            });
            case 15 -> {
                if (ct.isRightClick()) {
                    try {
                        p.playSound(p.getLocation(), d.openSound, SoundCategory.MASTER, d.soundVolume, d.soundPitch);
                    } catch (Exception ex) {
                        plugin.messages().send(p, "sound-invalid");
                    }
                } else {
                    plugin.input().ask(p, "ключ звуку, напр. entity.player.levelup", t -> {
                        if (!plugin.chests().isValidSound(t)) plugin.messages().send(p, "sound-invalid");
                        else {
                            d.openSound = t.toLowerCase();
                            plugin.plates().save();
                            plugin.messages().send(p, "gui-saved");
                        }
                        openPlate(p, d.id);
                    });
                }
            }
            case 16 -> {
                if (ct.isRightClick()) {
                    plugin.input().ask(p, "тип частинки, напр. happy_villager", t -> {
                        if (plugin.chests().resolveParticle(t) == null) plugin.messages().send(p, "particle-invalid");
                        else {
                            d.particle = t.toLowerCase();
                            plugin.plates().save();
                            plugin.messages().send(p, "gui-saved");
                        }
                        openPlate(p, d.id);
                    });
                } else {
                    d.particles = !d.particles;
                    plugin.plates().save();
                    render(h);
                }
            }
            case 19 -> openLoot(p, d.level, d.id, false);
            case 20 -> openLoot(p, d.level, d.id, true);
            case 24 -> plugin.plates().giveTo(p, d, 1);
            case 31 -> openMain(p);
            default -> { }
        }
    }

    // ================================================================== редактор луту

    private ItemStack lootIcon(LootEntry e, boolean hints) {
        ItemStack it = e.item.clone();
        it.setAmount(Math.max(1, Math.min(e.min, it.getMaxStackSize())));
        ItemMeta m = it.getItemMeta();
        if (m == null) return it;
        List<Component> existing = m.lore();
        List<Component> lore = existing == null ? new ArrayList<>() : new ArrayList<>(existing);
        lore.add(Component.empty());
        lore.add(Text.item("&7Шанс: &e" + num(e.chance) + "%"));
        lore.add(Text.item("&7Кількість: &a" + e.min + " &7- &a" + e.max));
        if (hints) {
            lore.add(Component.empty());
            lore.add(Text.item("&aКлік — редагувати"));
            lore.add(Text.item("&cShift+ПКМ — видалити"));
        }
        m.lore(lore);
        it.setItemMeta(m);
        return it;
    }

    private void renderLoot(PcHolder h) {
        Inventory inv = h.inventory;
        LootTable t = plugin.loot().table(h.level);
        int n = t.entries.size();
        int pages = Math.max(1, (n + 44) / 45);
        h.page = Math.max(0, Math.min(h.page, pages - 1));
        inv.clear();
        for (int i = 0; i < 45; i++) {
            int idx = h.page * 45 + i;
            if (idx >= n) break;
            inv.setItem(i, lootIcon(t.entries.get(idx), !h.readOnly));
        }
        ItemStack f = icon(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, f);
        if (h.page > 0) inv.setItem(45, icon(Material.ARROW, "&eПопередня сторінка"));
        if (h.page < pages - 1) inv.setItem(53, icon(Material.ARROW, "&eНаступна сторінка"));
        if (!h.readOnly) {
            inv.setItem(46, icon(Material.LIME_DYE, "&aДодати предмет з руки", "&7Кількість береться з руки,", "&7шанс за замовчуванням 100%"));
            inv.setItem(47, icon(Material.CLOCK, "&eРолів: &f" + t.rolls, "&7Скільки разів перевіряється таблиця", "", "&aЛКМ +1 &7| &cПКМ -1", "&7Shift — по 5"));
            inv.setItem(50, icon(Material.EMERALD, "&aЗберегти", "&7Зміни зберігаються автоматично"));
        } else {
            inv.setItem(47, icon(Material.CLOCK, "&eРолів: &f" + t.rolls));
        }
        inv.setItem(48, icon(Material.PAPER, "&7Предметів: &f" + n, "&7Сторінка " + (h.page + 1) + "/" + pages));
        inv.setItem(49, icon(Material.ARROW, "&cНазад"));
    }

    private void clickLoot(Player p, PcHolder h, int slot, ClickType ct) {
        LootTable t = plugin.loot().table(h.level);
        if (slot < 45) {
            int idx = h.page * 45 + slot;
            if (h.readOnly || idx >= t.entries.size()) return;
            LootEntry en = t.entries.get(idx);
            if (ct == ClickType.SHIFT_RIGHT) {
                t.entries.remove(en);
                plugin.loot().save(t);
                render(h);
            } else {
                openEntry(p, h, en.id);
            }
            return;
        }
        switch (slot) {
            case 45 -> {
                if (h.page > 0) {
                    h.page--;
                    render(h);
                }
            }
            case 53 -> {
                h.page++;
                render(h);
            }
            case 46 -> {
                if (h.readOnly) return;
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType().isAir()) {
                    plugin.messages().send(p, "gui-no-item");
                    return;
                }
                ItemStack tpl = hand.clone();
                tpl.setAmount(1);
                LootEntry en = new LootEntry(plugin.loot().newEntryId(), tpl);
                en.min = hand.getAmount();
                en.max = hand.getAmount();
                t.entries.add(en);
                plugin.loot().save(t);
                h.page = Math.max(0, (t.entries.size() - 1) / 45);
                render(h);
            }
            case 47 -> {
                if (h.readOnly) return;
                int delta = ct.isShiftClick() ? 5 : 1;
                if (ct.isRightClick()) delta = -delta;
                t.rolls = Math.max(1, t.rolls + delta);
                plugin.loot().save(t);
                render(h);
            }
            case 50 -> {
                if (h.readOnly) return;
                plugin.loot().save(t);
                plugin.messages().send(p, "gui-saved");
            }
            case 49 -> {
                if (h.plateId != null && plugin.plates().get(h.plateId) != null) openPlate(p, h.plateId);
                else openMain(p);
            }
            default -> { }
        }
    }

    // ================================================================== редактор одного предмета

    private void deltaButtons(Inventory inv, int[] slots, int[] deltas, String suffix) {
        for (int i = 0; i < slots.length; i++) {
            int d = deltas[i];
            inv.setItem(slots[i], icon(d < 0 ? Material.RED_STAINED_GLASS_PANE : Material.LIME_STAINED_GLASS_PANE,
                    (d < 0 ? "&c" : "&a+") + d + suffix, "&7Клік — змінити"));
        }
    }

    private void renderEntry(PcHolder h) {
        Inventory inv = h.inventory;
        fill(inv);
        LootEntry e = plugin.loot().table(h.level).find(h.entryId);
        if (e == null) return;
        inv.setItem(4, lootIcon(e, false));
        deltaButtons(inv, CH_SLOTS, CH_DELTA, "%");
        inv.setItem(13, icon(Material.GOLD_NUGGET, "&eШанс: &f" + num(e.chance) + "%", "&aКлік — ввести значення (0-100)"));
        deltaButtons(inv, MIN_SLOTS, Q_DELTA, "");
        inv.setItem(22, icon(Material.IRON_NUGGET, "&eМінімум: &f" + e.min, "&aКлік — ввести значення"));
        deltaButtons(inv, MAX_SLOTS, Q_DELTA, "");
        inv.setItem(31, icon(Material.COPPER_INGOT, "&eМаксимум: &f" + e.max, "&aКлік — ввести значення"));
        inv.setItem(36, icon(Material.BARRIER, "&cВидалити предмет з луту"));
        inv.setItem(40, icon(Material.ARROW, "&cНазад"));
    }

    private void clickEntry(Player p, PcHolder h, int slot) {
        LootTable t = plugin.loot().table(h.level);
        LootEntry e = t.find(h.entryId);
        if (e == null) {
            openLoot(p, h.level, h.plateId, false);
            return;
        }
        int ci = indexOf(CH_SLOTS, slot);
        int mi = indexOf(MIN_SLOTS, slot);
        int xi = indexOf(MAX_SLOTS, slot);
        if (ci >= 0) {
            e.chance = Math.max(0, Math.min(100, e.chance + CH_DELTA[ci]));
            changed(t, h);
            return;
        }
        if (mi >= 0) {
            e.min = Math.max(1, e.min + Q_DELTA[mi]);
            if (e.max < e.min) e.max = e.min;
            changed(t, h);
            return;
        }
        if (xi >= 0) {
            e.max = Math.max(1, e.max + Q_DELTA[xi]);
            if (e.min > e.max) e.min = e.max;
            changed(t, h);
            return;
        }
        switch (slot) {
            case 13 -> plugin.input().ask(p, "шанс у % (0-100)", s -> {
                Double v = parseDouble(s);
                if (v == null || v < 0 || v > 100) invalid(p);
                else {
                    e.chance = v;
                    plugin.loot().save(t);
                }
                reopenEntry(p, h);
            });
            case 22 -> plugin.input().ask(p, "мінімальна кількість (≥ 1)", s -> {
                Integer v = parseInt(s);
                if (v == null || v < 1) invalid(p);
                else {
                    e.min = v;
                    if (e.max < v) e.max = v;
                    plugin.loot().save(t);
                }
                reopenEntry(p, h);
            });
            case 31 -> plugin.input().ask(p, "максимальна кількість (≥ 1)", s -> {
                Integer v = parseInt(s);
                if (v == null || v < 1) invalid(p);
                else {
                    e.max = v;
                    if (e.min > v) e.min = v;
                    plugin.loot().save(t);
                }
                reopenEntry(p, h);
            });
            case 36 -> {
                t.entries.remove(e);
                plugin.loot().save(t);
                openLoot(p, h.level, h.plateId, false);
            }
            case 40 -> openLoot(p, h.level, h.plateId, false);
            default -> { }
        }
    }

    private void changed(LootTable t, PcHolder h) {
        plugin.loot().save(t);
        render(h);
    }

    private void reopenEntry(Player p, PcHolder h) {
        PcHolder n = new PcHolder(PcHolder.Type.ENTRY);
        n.level = h.level;
        n.plateId = h.plateId;
        n.entryId = h.entryId;
        open(p, n, 45, "&8Предмет » Рівень " + h.level);
    }

    // ================================================================== створення сундуків

    private void renderChests(PcHolder h) {
        Inventory inv = h.inventory;
        fill(inv);
        int i = 0;
        for (PlateDef d : plugin.plates().all()) {
            if (i >= 7) break;
            inv.setItem(10 + i++, icon(Material.CHEST, d.name + " &7(рівень " + d.level + ")",
                    "&aЛКМ — поставити сундук", "&6ПКМ — поставити бочку", "&7на вашому місці"));
        }
        inv.setItem(22, icon(Material.ARROW, "&cНазад"));
    }

    private void clickChests(Player p, int slot, ClickType ct) {
        if (slot == 22) {
            openMain(p);
            return;
        }
        List<PlateDef> list = new ArrayList<>(plugin.plates().all());
        int idx = slot - 10;
        if (idx < 0 || idx >= 7 || idx >= list.size()) return;
        ChestData.Type type = ct.isRightClick() ? ChestData.Type.BARREL : ChestData.Type.CHEST;
        if (!ct.isLeftClick() && !ct.isRightClick()) return;
        p.closeInventory();
        plugin.chests().place(p, type, list.get(idx).level);
    }

    // ================================================================== налаштування

    private void renderSettings(PcHolder h) {
        Inventory inv = h.inventory;
        fill(inv);
        var c = plugin.configs().config();
        inv.setItem(10, icon(Material.NOTE_BLOCK, "&eЗвуки відкриття", "&7" + onOff(c.getBoolean("effects.sounds-enabled", true)), "&aКлік — перемкнути"));
        inv.setItem(11, icon(Material.BLAZE_POWDER, "&eЧастинки", "&7" + onOff(c.getBoolean("effects.particles-enabled", true)), "&aКлік — перемкнути"));
        inv.setItem(12, icon(Material.WRITABLE_BOOK, "&eЛогування відкриттів", "&7" + onOff(c.getBoolean("settings.log-opens", true)), "&aКлік — перемкнути"));
        inv.setItem(13, icon(Material.HOPPER, "&eПовторне відкриття", "&7Режим: &f" + c.getString("chests.reopen-mode", "ANYONE"),
                "&7ANYONE — будь-хто забирає залишок", "&7OPENER — лише відкривач", "&7NONE — залишок випадає", "&aКлік — змінити"));
        inv.setItem(14, icon(Material.ARMOR_STAND, "&eАнімація відкриття", "&7" + onOff(c.getBoolean("chests.open-animation", true)), "&aКлік — перемкнути"));
        inv.setItem(15, icon(Material.CHEST_MINECART, "&eКласти власні предмети", "&7" + onOff(c.getBoolean("chests.allow-put-items", false)), "&aКлік — перемкнути"));
        inv.setItem(16, icon(Material.COMMAND_BLOCK, "&6Перезавантажити конфіги", "&aКлік — /pcases reload"));
        inv.setItem(22, icon(Material.ARROW, "&cНазад"));
    }

    private void toggle(String path, boolean def) {
        var c = plugin.configs().config();
        c.set(path, !c.getBoolean(path, def));
        plugin.configs().saveConfig();
    }

    private void clickSettings(Player p, PcHolder h, int slot) {
        switch (slot) {
            case 10 -> toggle("effects.sounds-enabled", true);
            case 11 -> toggle("effects.particles-enabled", true);
            case 12 -> toggle("settings.log-opens", true);
            case 13 -> {
                var c = plugin.configs().config();
                String cur = c.getString("chests.reopen-mode", "ANYONE").toUpperCase();
                String next = switch (cur) {
                    case "ANYONE" -> "OPENER";
                    case "OPENER" -> "NONE";
                    default -> "ANYONE";
                };
                c.set("chests.reopen-mode", next);
                plugin.configs().saveConfig();
            }
            case 14 -> toggle("chests.open-animation", true);
            case 15 -> toggle("chests.allow-put-items", false);
            case 16 -> {
                plugin.reloadAll();
                plugin.messages().send(p, "reloaded");
            }
            case 22 -> {
                openMain(p);
                return;
            }
            default -> {
                return;
            }
        }
        render(h);
    }

    // ================================================================== статистика

    private void renderStats(PcHolder h) {
        Inventory inv = h.inventory;
        fill(inv);
        var cm = plugin.chests();
        int total = cm.all().size();
        int unused = cm.countUnused();
        inv.setItem(4, icon(Material.CHEST, "&6Загальна статистика",
                "&7Зареєстровано сундуків: &f" + total,
                "&7Відкрито: &a" + (total - unused),
                "&7Не відкрито: &e" + unused,
                "&7Відкрито за весь час: &f" + cm.totalOpened()));
        int i = 0;
        for (PlateDef d : plugin.plates().all()) {
            if (i >= 14) break;
            ItemStack it = plugin.plates().create(d, 1, false);
            ItemMeta m = it.getItemMeta();
            List<Component> lore = new ArrayList<>();
            lore.add(Text.item("&7Рівень: &e" + d.level));
            lore.add(Text.item("&7Сундуків відкрито: &a" + cm.levelOpened(d.level)));
            m.lore(lore);
            it.setItemMeta(m);
            inv.setItem(PLATE_SLOTS[i++], it);
        }
        inv.setItem(22, icon(Material.ARROW, "&cНазад"));
    }

    // ================================================================== події

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof PcHolder h)) return;
        e.setCancelled(true); // жодних змін у GUI, shift-click, hotbar-swap тощо
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != top) return;
        if (!p.hasPermission("platecases.admin")) {
            p.closeInventory();
            return;
        }
        int slot = e.getSlot();
        ClickType ct = e.getClick();
        switch (h.type) {
            case MAIN -> clickMain(p, h, slot);
            case PLATE -> clickPlate(p, h, slot, ct);
            case LOOT -> clickLoot(p, h, slot, ct);
            case ENTRY -> clickEntry(p, h, slot);
            case CHESTS -> clickChests(p, slot, ct);
            case SETTINGS -> clickSettings(p, h, slot);
            case STATS -> {
                if (slot == 22) openMain(p);
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder(false) instanceof PcHolder) e.setCancelled(true);
    }
}
