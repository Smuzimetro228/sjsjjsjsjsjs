# PlateCases 1.0.0 (автор: FlipTime)
Paper 1.21.11 · Java 21 · Maven. Пластинки 3 рівнів відкривають спеціальні сундуки/бочки з випадковим лутом.

## Встановлення
1. Зберіть плагін (див. «Компіляція») або покладіть готовий `PlateCases.jar` у `plugins/`.
2. Запустіть сервер — створяться `config.yml`, `messages.yml`, `items.yml`, `chests.yml`, `loot/level1-3.yml`.
3. (Необов'язково) встановіть PlaceholderAPI.

## Компіляція
```
mvn clean package
```
Готовий файл: `target/PlateCases.jar`. Потрібні JDK 21 та доступ до репозиторіїв papermc.io і extendedclip.com.

## Команди (permission: platecases.admin)
| Команда | Опис |
|---|---|
| `/pcases menu` | головне GUI-меню |
| `/pcases place chest [рівень]` | спеціальний сундук на вашому місці |
| `/pcases place barrel [рівень]` | спеціальна бочка (підлога/стіна/стеля — за кутом погляду) |
| `/pcases give plastivka1\|2\|3 [к-сть]` | видати собі |
| `/pcases give <гравець> <plastivka> [к-сть]` | видати гравцю |
| `/pcases remove [id]` | видалити сундук (за поглядом або id) |
| `/pcases list [стор]` / `/pcases tp <id>` | список / телепорт |
| `/pcases reload` | перезавантажити конфіги |

Гравцям потрібен `platecases.use` (за замовчуванням є у всіх).

## Як це працює
ПКМ по спеціальному сундуку пластинкою в **основній руці**. Перевірки (до витрати пластинки): пластинка в руці → справжня (PDC-id + підпис) → рівень збігається → лут налаштований. Далі витрачається 1 пластинка, лут генерується **один раз** у випадкових унікальних слотах і зберігається в `chests.yml`.
Режим `chests.reopen-mode` визначає, чи можна забрати залишок луту пізніше (пластинка за повторне відкриття ніколи не витрачається).

## Конфігурація
- `items.yml` — назва, матеріал (текстура), CustomModelData, item-model, рівень, звук, частинки. Нові рівні — нова секція + `/pcases reload`.
- `loot/levelN.yml` — `rolls`, а для кожного запису `chance` (%), `min`, `max`. Формат запису: `material` (+`potion`) або `item` (його пише GUI).
- `messages.yml` — усі повідомлення (&-коди, `&#RRGGBB`, MiniMessage).
- `config.yml` — розміри інвентарів, режими, ефекти.

## PlaceholderAPI
`%platecases_opened%`, `%platecases_opened_total%`, `%platecases_opened_level_N%`, `%platecases_chests_total%`, `%platecases_chests_used%`, `%platecases_chests_unused%`.
